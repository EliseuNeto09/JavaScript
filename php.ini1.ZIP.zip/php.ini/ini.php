<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
date_default_timezone_set('America/Sao_Paulo');

$dataAtual = date('Y-m-d'); 

// Tradução manual dos meses e dias da semana
$meses = array(
    '01' => 'Janeiro',
    '02' => 'Fevereiro',
    '03' => 'Março',
    '04' => 'Abril',
    '05' => 'Maio',
    '06' => 'Junho',
    '07' => 'Julho',
    '08' => 'Agosto',
    '09' => 'Setembro',
    '10' => 'Outubro',
    '11' => 'Novembro',
    '12' => 'Dezembro'
);

$dias_semana = array(
    'Sunday'    => 'Domingo',
    'Monday'    => 'Segunda-feira',
    'Tuesday'   => 'Terça-feira',
    'Wednesday' => 'Quarta-feira',
    'Thursday'  => 'Quinta-feira',
    'Friday'    => 'Sexta-feira',
    'Saturday'  => 'Sábado'
);

// Obtenha partes da data
$ano = date('Y', strtotime($dataAtual));
$mes = date('m', strtotime($dataAtual));
$dia = date('d', strtotime($dataAtual));
$dia_semana = date('l', strtotime($dataAtual));

echo "Data Atual em Português: {$dias_semana[$dia_semana]}, {$dia} de {$meses[$mes]} de {$ano}";
?>


</body>
</html>